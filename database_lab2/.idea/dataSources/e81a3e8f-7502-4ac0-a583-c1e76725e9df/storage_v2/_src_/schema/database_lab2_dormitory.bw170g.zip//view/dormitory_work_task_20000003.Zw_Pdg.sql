create view dormitory_work_task_20000003 as
(
select `database_lab2_dormitory`.`work_task`.`work_task_num`         AS `work_task_num`,
       `database_lab2_dormitory`.`work_task`.`dormitory_num`         AS `dormitory_num`,
       `database_lab2_dormitory`.`dormitory_adm`.`dormitory_adm_num` AS `dormitory_adm_num`
from (`database_lab2_dormitory`.`dormitory_adm`
         join `database_lab2_dormitory`.`work_task` on ((`database_lab2_dormitory`.`dormitory_adm`.`dormitory_adm_num` =
                                                         `database_lab2_dormitory`.`work_task`.`dormitory_adm_num`)))
where (`database_lab2_dormitory`.`dormitory_adm`.`dormitory_adm_num` = '20000003'));

-- comment on column dormitory_work_task_20000003.work_task_num not supported: 工作任务号

-- comment on column dormitory_work_task_20000003.dormitory_num not supported: 宿舍号

-- comment on column dormitory_work_task_20000003.dormitory_adm_num not supported: 宿管号

