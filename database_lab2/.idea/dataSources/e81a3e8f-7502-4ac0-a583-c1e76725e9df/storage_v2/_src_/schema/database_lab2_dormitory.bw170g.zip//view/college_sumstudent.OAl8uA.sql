create view college_sumstudent as
(
select `database_lab2_dormitory`.`apply_stay_prove`.`sign_prove_college` AS `sign_prove_college`,
       count(`database_lab2_dormitory`.`apply_stay_prove`.`student_num`) AS `sum_student`
from `database_lab2_dormitory`.`apply_stay_prove`
group by `database_lab2_dormitory`.`apply_stay_prove`.`sign_prove_college`);

-- comment on column college_sumstudent.sign_prove_college not supported: 开具证明学院

