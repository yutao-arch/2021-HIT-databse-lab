create definer = root@localhost view college_student_language as
(
select `database_lab2_dormitory`.`student_information`.`student_num` AS `student_num`,
       `database_lab2_dormitory`.`student_information`.`name`        AS `name`,
       `database_lab2_dormitory`.`student_information`.`age`         AS `age`,
       `database_lab2_dormitory`.`student_information`.`id_card_num` AS `id_card_num`,
       `database_lab2_dormitory`.`student_information`.`sex`         AS `sex`
from `database_lab2_dormitory`.`student_information`
where `database_lab2_dormitory`.`student_information`.`student_num` in
      (select `database_lab2_dormitory`.`apply_stay_prove`.`student_num`
       from `database_lab2_dormitory`.`apply_stay_prove`
       where (`database_lab2_dormitory`.`apply_stay_prove`.`sign_prove_college` = '外语学院')));

-- comment on column college_student_language.student_num not supported: 学号

-- comment on column college_student_language.name not supported: 姓名

-- comment on column college_student_language.age not supported: 年龄

-- comment on column college_student_language.id_card_num not supported: 身份证号

-- comment on column college_student_language.sex not supported: 性别

